<template>
  <div></div>
</template>

<script setup>
const router = useRouter();
onMounted(() => {
  router.push("/orders");
});
</script>
