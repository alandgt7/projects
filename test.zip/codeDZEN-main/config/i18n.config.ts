export default {
  legacy: false,
  locale: "en",
  fallbackLocale: "en",
  messages: {},
};
