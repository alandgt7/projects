<template>
  <div class="wrapper">
    <NuxtImg src="/loader.svg" alt="" width="220" />
  </div>
</template>

<style scoped>
.wrapper {
  background-color: #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
  height: 100vh;
}
</style>
